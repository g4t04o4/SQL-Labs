create trigger TR_SEQ_1
    before insert
    on УСПЕВАЕМОСТЬ
    for each row
BEGIN
                        SELECT ASC_NUM_1.nextval   INTO :new.НОМЕР  FROM dual; 
           END;
/

