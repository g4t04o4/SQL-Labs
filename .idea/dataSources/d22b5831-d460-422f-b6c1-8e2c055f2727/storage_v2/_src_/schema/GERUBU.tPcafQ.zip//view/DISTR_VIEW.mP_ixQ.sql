CREATE VIEW DISTR_VIEW AS
WITH T AS (
    SELECT DISTINCT DEPARTMENT_ID   DEP_ID,
                    DEPARTMENT_NAME DEP_NAME,
                    JOB_ID,
                    CNT,
                    SAL
    FROM EMPLOYEES
             LEFT JOIN DEPARTMENTS
                       USING (DEPARTMENT_ID)
    WHERE JOB_ID IN ('ST_CLERK', 'ST_MAN', 'AD_PRES', 'SA_REP')
        AND DEPARTMENT_NAME IN ('Shipping', 'Executive')
       OR DEPARTMENT_ID IS NULL
        MODEL
            PARTITION BY (DEPARTMENT_ID, DEPARTMENT_NAME)
            DIMENSION BY (JOB_ID, EMPLOYEE_ID)
            MEASURES (0 CNT, 0 SAL, SALARY, EMPLOYEE_ID EMP_ID)
            RULES UPSERT ALL (
            CNT[FOR JOB_ID IN ('ST_CLERK', 'ST_MAN', 'AD_PRES', 'SA_REP'),ANY] = COUNT(EMP_ID)[CV(), ANY],
            SAL[ANY,ANY] = SUM(SALARY)[CV(), ANY])
    ORDER BY 1, 5 DESC NULLS LAST, 4, 3)
SELECT ROWNUM  ID,
       DEP_ID,
       DEP_NAME,
       JOB_ID,
       CASE
           WHEN CNT = 0
               THEN NULL
           ELSE CNT
           END CNT,
       SAL
FROM T
/

