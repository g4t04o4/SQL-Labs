create view MAIN_VIEW as
SELECT View_tmp1.Номер_договора,View_tmp1.Дата_заключения_договора,View_tmp1.ИНН_клиента,View_tmp1.Название,View_tmp2.Фамилия,View_tmp2.Имя,View_tmp2.Отчество,View_tmp2.Контактный_номер_клиента
		FROM View_tmp1 ,View_tmp2 
		WHERE View_tmp1.Номер_договора = View_tmp2.Номер_договора
/

