create view VIEW_TMP1 as
SELECT ERwin_Договор.Номер_договора,ERwin_Договор.Дата_заключения_договора,ERwin_Клиент.ИНН_клиента,ERwin_Юридическое_лицо.Название
		FROM ERwin_Договор ,ERwin_Клиент ,ERwin_Юридическое_лицо 
		WHERE ERwin_Договор.Дата_отправления > sysdate AND ERwin_Договор.Тип_клиента = 'корп'
/

